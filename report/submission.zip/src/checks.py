"""Check finite observations, never treat unavailability as a safety violation."""

def classify(model, operations):
    if any(op['status'] != 'ok' for op in operations):
        return 'inconclusive'
    if model == 'RYW':
        violation = operations[-1]['value']['a'] < 1
    elif model == 'MR':
        violation = operations[-1]['value']['a'] < operations[-2]['value']['a']
    elif model in ('MW', 'WFR'):
        value = operations[-1]['value']
        # An absent successor is not a witness of out-of-order visibility.
        if value['b'] != 1:
            return 'inconclusive'
        violation = value['a'] != 1
    else:
        raise ValueError(model)
    return 'violation' if violation else 'no_violation_observed'
