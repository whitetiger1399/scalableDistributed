"""JSON request/response worker, executed inside the client container."""
import json
import logging
import socket
import sys
import time
from cassandra import ConsistencyLevel
from cassandra.cluster import Cluster, ExecutionProfile, EXEC_PROFILE_DEFAULT
from cassandra.policies import WhiteListRoundRobinPolicy, FallthroughRetryPolicy, NoSpeculativeExecutionPolicy
from cassandra.query import SimpleStatement
from checks import classify

logging.basicConfig(level=logging.ERROR)

class Client:
    def __init__(self):
        self.clusters = []
        self.sessions = {}
    def session(self, node):
        if node not in self.sessions:
            ip = socket.gethostbyname(node)
            profile = ExecutionProfile(load_balancing_policy=WhiteListRoundRobinPolicy([ip]),
                retry_policy=FallthroughRetryPolicy(),
                speculative_execution_policy=NoSpeculativeExecutionPolicy(), request_timeout=12)
            cluster = Cluster([ip], execution_profiles={EXEC_PROFILE_DEFAULT: profile},
                              protocol_version=4, connect_timeout=8)
            self.clusters.append(cluster)
            self.sessions[node] = cluster.connect()
        return self.sessions[node]

    def close(self):
        for cluster in self.clusters:
            cluster.shutdown()

    def op(self, node, query, params=(), cl='ALL'):
        start = time.time_ns()
        record = dict(node=node, query=query, params=list(params), cl=cl, start_ns=start)
        try:
            future = self.session(node).execute_async(SimpleStatement(query,
                consistency_level=getattr(ConsistencyLevel, cl)), params)
            rows = list(future.result())
            record.update(status='ok', value=rows[0]._asdict() if rows else None,
                          coordinator=str(future.coordinator_host))
        except Exception as exc:
            record.update(status='error', error=type(exc).__name__, message=str(exc))
        record.update(end_ns=time.time_ns(), latency_ms=(time.time_ns()-start)/1e6)
        return record

    def read(self, node, key, cl, table='blocking'):
        return self.op(node, f'SELECT a,b FROM lab.{table} WHERE k=%s', (key,), cl)

    def write(self, node, key, column, value, ts, cl, table='blocking'):
        assert column in ('a', 'b')
        return self.op(node, f'UPDATE lab.{table} USING TIMESTAMP %s SET {column}=%s WHERE k=%s',
                       (ts, value, key), cl)

def main(req, c):
    action = req['action']
    if action == 'schema':
        queries = ["CREATE KEYSPACE IF NOT EXISTS lab WITH replication = {'class':'NetworkTopologyStrategy','dc1':3}"]
        queries += [f"CREATE TABLE IF NOT EXISTS lab.{t} (k text PRIMARY KEY, a int, b int) WITH read_repair='{rr}' AND speculative_retry='NONE'" for t,rr in [('blocking','BLOCKING'),('no_repair','NONE')]]
        result = [c.op('n1', q) for q in queries]
        result += [c.op(n, 'SELECT release_version, data_center, rack FROM system.local') for n in ('n1','n2','n3')]
        return result
    if action == 'init':
        records = []
        for key in req['keys']:
            for table in req.get('tables', ['blocking']):
                records.append(c.op('n1', f'INSERT INTO lab.{table} (k,a,b) VALUES (%s,0,0) USING TIMESTAMP %s', (key, req['ts']), 'ALL'))
        return records
    if action == 'op':
        if req['kind'] == 'read':
            return c.read(req['node'], req['key'], req['cl'], req.get('table','blocking'))
        return c.write(req['node'], req['key'], req['column'], req['value'], req['ts'], req['cl'], req.get('table','blocking'))
    if action == 'batch':
        trials = []
        target = 'n2' if req['scenario'] == 'node_failure' else 'n3'
        for config in req['configs']:
            w, r = config.split('/')
            for model in ('RYW', 'MR', 'MW', 'WFR'):
                for i in range(req['repeats']):
                    key = f"{req['prefix']}:{config}:{model}:{i}"
                    ts = req['ts'] + i*10
                    ops = [c.write('n1', key, 'a', 1, ts, w)]
                    if model == 'RYW':
                        ops += [c.read(target, key, r)]
                    elif model == 'MR':
                        ops += [c.read('n1', key, r), c.read(target, key, r)]
                    elif model == 'MW':
                        ops += [c.write(target, key, 'b', 1, ts+1, w), c.read(target, key, r)]
                    else:
                        ops += [c.read('n1', key, r), c.write(target, key, 'b', 1, ts+1, w), c.read(target, key, r)]
                    # WFR needs an actual read of its dependency to establish the edge.
                    verdict = classify(model, ops)
                    if model == 'WFR' and (ops[1]['status'] != 'ok' or ops[1]['value']['a'] != 1):
                        verdict = 'inconclusive'
                    trials.append(dict(scenario=req['scenario'], config=config, model=model,
                                       repetition=i, key=key, operations=ops, verdict=verdict))
        return trials
    raise ValueError(action)

if __name__ == '__main__':
    request = json.load(sys.stdin)
    client = Client()
    try:
        print(json.dumps(main(request, client), default=str))
    finally:
        client.close()
